Downloaded from http://vasc.ri.cmu.edu/idb/images/motion/cil/




Motion sequence: forwardL0-L9

Image: 480x512 grayscale.

Description: First image in the same place as horizL9 and vertL0.  Spacing of .2 inch.

